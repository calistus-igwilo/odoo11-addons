To use this module, you need to:

#. Go to any of your website pages.
#. Edit it.
#. Drag and drop the *Form* snippet into the page.
#. Use the snippet overlay to add, edit and remove fields.
#. If you want to set a hidden field, make sure you set a valid default value
   on it, or users may get hidden errors and they might even be unable to send
   the form!
