Project Report v11
==================
PDF and XLS Reports for Project Module.


Features
========
* Project Tasks Report XLS [With advanced Filtration]
* Project Tasks Report PDF [With advanced Filtration]

Installation
============
To install this module, you need also the **report_xlsx**

Credits
=======
Cybrosys Techno Solutions <www.cybrosys.com>

Author
------
*  Developer V9: Avinash Nk @ cybrosys
*  Developer V10: Treesa @ cybrosys
*  Developer V11: Akshay
