v1.0.14
=======
* Fix form defaults for many2one

v1.0.13
=======
* Fix dropbox (many2one) domain filter so it actually works...

v1.0.12
=======
* Remove domain from submit url to better deal with multi domain websites
* Dropbox (many2one) now uses the fields domain if present

v1.0.11
=======
* Fix permission issue with public form submissions that had many2many default values that public can't access

v1.0.10
=======
* Port email submit function over to 11 buy use email template system to allow customisation

v1.0.9
======
* Fix csrf being saved in html

v1.0.8
======
* Fix custom actions from not working

v1.0.7
======
* Fix form javascript public access issue

v1.0.6
======
* Fix input group generating incorrect html

v1.0.5
======
* Textboxes now add the required attribute

v1.0.4
======
* Fix Captcha not regenerating
* Fix date and datetime picker having invalid parameters

v1.0.3
======
* Move recaptcha to inline to avoid bundling issues

v1.0.2
======
* Fix duplicate my_pie and issue with Odoo always outputting http even with https websites

v1.0.1
======
* Fix character encoding issue

v1.0.0
======
* Ported to version 11