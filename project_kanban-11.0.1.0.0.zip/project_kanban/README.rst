===============
Project Kanban
===============

* Get to know your current Project status by activities.

* This module helps the project management team know the idle projects by the last updated date on the project and recent updated date for  the Project communication.

* Last update date shows the last update date and time of particular project.

Usage
=====

Bug Tracker
===========

Credits
=======

Contributors
------------

* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>

